#!/bin/bash
cd packages/services/QualifiedNetworksService
git am ../../../0001-qns-track-the-system-default-network-through-app-VPN.patch
