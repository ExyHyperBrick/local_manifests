#!/bin/bash
cd build/make/core/
git am ../../../PATCHES/build_core_000*
cd ../../../build/soong/
git am ../../PATCHES/build_soong_0001*
cd ../../system/tools/mkbootimg/
git am ../../../PATCHES/system_tools_mkbootimg_433617.diff
cd ../../../external/cronet/
git am ../../PATCHES/external_cronet_433320.diff
cd ../../packages/services/QualifiedNetworksService
git am ../../../0001-qns-track-the-system-default-network-through-app-VPN.patch
